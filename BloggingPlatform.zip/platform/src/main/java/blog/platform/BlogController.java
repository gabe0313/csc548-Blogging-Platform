package blog.platform;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable; 




@Controller
@RequestMapping("/blog")
public class BlogController {

    private final BlogService blogService;

    @Autowired
    public BlogController(BlogService blogService) {
        this.blogService = blogService;
    }

    @GetMapping
    public String listBlogPosts(Model model) {
        model.addAttribute("blogPosts", blogService.getAllPosts());
        model.addAttribute("newPost", new BlogPost());
        return "blog";
    }

    @PostMapping("/add")
    public String addBlogPost(@ModelAttribute BlogPost newPost) {
        blogService.createPost(newPost);
        return "redirect:/blog";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Integer id, Model model) {
        BlogPost blogPost = blogService.getPostById(id);
        model.addAttribute("blogPost", blogPost);
        return "editBlog";
    }

    @PostMapping("/update")
    public String updateBlogPost(@ModelAttribute BlogPost blogPost) {
        blogService.updatePost(blogPost);
        return "redirect:/blog";
    }

    @GetMapping("/delete/{id}")
    public String deleteBlogPost(@PathVariable Integer id) {
        blogService.deletePost(id);
        return "redirect:/blog";
    }
}