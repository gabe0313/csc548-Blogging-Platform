package blog.platform;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.ArrayList;



@Service
public class BlogService {
    private final List<BlogPost> blogPosts = new ArrayList<>();

    public List<BlogPost> getAllPosts() {
        return new ArrayList<>(blogPosts);
    }

    public void createPost(BlogPost blogPost) {
        blogPosts.add(blogPost);
    }

    public void updatePost(BlogPost updatedPost) {
        blogPosts.removeIf(b -> b.getId().equals(updatedPost.getId()));
        blogPosts.add(updatedPost);
    }

    public void deletePost(Integer postId) {
        blogPosts.removeIf(b -> b.getId().equals(postId));
    }

    public BlogPost getPostById(Integer postId) {
        return blogPosts.stream().filter(b -> b.getId().equals(postId)).findFirst().orElse(null);
    }
}