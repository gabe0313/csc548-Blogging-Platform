package blog.platform;
import java.util.concurrent.atomic.AtomicInteger;


public class BlogPost {
    private static final AtomicInteger count = new AtomicInteger(0);
    private Integer id;
    private String title;
    private String content;

    public BlogPost() {
        this.id = count.incrementAndGet();
    }

    public static AtomicInteger getCount() {
        return count;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    
}